<div class="bg-danger p-3 text-center">
  <p>All rights reserved @Designed by-Aditya 2024</p>
</div>