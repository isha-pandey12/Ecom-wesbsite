<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Orders</title>
    <!-- Bootstrap CSS -->
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <style>
        body {
            background-color: #f8f9fa;
            overflow: hidden; /* Remove scrollbar */
        }
        .table th, .table td {
            vertical-align: middle;
        }
        .navbar {
            margin-bottom: 20px;
        }
        .container {
            margin-top: 50px;
        }
    </style>
</head>
<body>

<!-- Navbar
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <a class="navbar-brand" href="#">My Store</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav ml-auto">
            <li class="nav-item">
                <a class="nav-link" href="#">Home</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#">Orders</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#">Profile</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#">Logout</a>
            </li>
        </ul>
    </div>
</nav> -->

<div class="container">
    <h3 class="text-success mb-4">All My Orders</h3>
    <div class="table-responsive">
        <table class="table table-bordered table-hover">
            <thead class="thead-dark">
            <tr>
                <th>S.No</th>
                <th>Amount Due</th>
                <th>Total Products</th>
                <th>Invoice Number</th>
                <th>Date</th>
                <th>Complete/Incomplete</th>
                <th>Status</th>
            </tr>
            </thead>
            <tbody>
            <?php  
            $username=$_SESSION['username'];
            $get_user="SELECT * FROM user_table WHERE username='$username'";
            $result=mysqli_query($con,$get_user);
            $row_fetch=mysqli_fetch_assoc($result);
            $user_id=$row_fetch['user_id'];

            $get_order_deatils="SELECT * FROM user_orders WHERE user_id=$user_id";
            $result_orders=mysqli_query($con,$get_order_deatils);
            $number=1;
            while($row_orders=mysqli_fetch_assoc($result_orders)){
                $order_id=$row_orders['order_id'];
                $amount_due=$row_orders['amount_due'];
                $invoice_number=$row_orders['invoice_number'];
                $total_products=$row_orders['total_products'];
                $order_status=$row_orders['order_status'];
                if ($order_status == 'pending') {
                    $order_status = 'Incomplete';
                } else {
                    $order_status = 'Complete';
                }
                $order_date=$row_orders['order_date'];
                echo "<tr>
                        <td>$number</td>
                        <td>$amount_due</td>
                        <td>$total_products</td>
                        <td>$invoice_number</td>
                        <td>$order_date</td>
                        <td>$order_status</td>";
                if($order_status=='Complete'){
                    echo "<td>Paid</td>";
                }else{
                    echo "<td><a href='confirm_payment.php?order_id=$order_id' class='btn btn-primary btn-sm'>Confirm</a></td></tr>";
                }
                $number++;
            }
            ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Bootstrap JS and dependencies -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>