<!-- Bootstrap CSS CDN -->
<link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome CDN -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

 
 <h3 class="text-center text-success">All Users</h3>
 <table class="table table-hover table-striped table-bordered">
            <thead class="thead-dark">
        <tr class="text-center">

    <?php 
    
    $get_users="SELECT * FROM `user_table`";
    $result=mysqli_query($con,$get_users);
    $row_count=mysqli_num_rows($result);

    if($row_count==0){
        echo "<h2 class='text-danger text-center mt-5'>No Users yet</h2>";
    }else{
      echo "<tr class='text-center'>
      <th>SNo.</th>
      <th>Username</th>
      <th>User Email</th>
      <th>User Image</th>
      <th>User Address</th>
      <th>User Mobile</th>
      <th>Delete</th>
  </tr>
  </thead>
  <tbody class='bg-light' >";
        $number=0;
        while($row_data=mysqli_fetch_assoc($result)){
            $user_id=$row_data['user_id'];
            $username =$row_data['username'];
            $user_email=$row_data['user_email'];
            $user_image=$row_data['user_image'];
            $user_address	=$row_data['user_address'];
            $user_mobile=$row_data['user_mobile'];
            $number++;
            echo "
        <tr class='text-center'>
            <td>$number</td>
            <td>$username</td>
            <td>$user_email</td>
            <td><img src='../users_area/user_images/$user_image' 
            alt='$username' class='product_img'></td>
            <td>$user_address</td>
            <td>$user_mobile</td>
           <td><a href='index.php?delete_users=$user_id'
            type='button' class='text-dark' data-toggle='modal'data-target='#exampleModalCenter'>
            <i class='fa fa-trash' aria-hidden='true'></i></a></td> 
           
        </tr>";
        }
        
    }

    ?>

    </tbody>
</table>



<!-- Modal -->
<div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" 
aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">Delete Confirmation</h5>

      </div>
      <div class="modal-body">
        <h>Are you sure you want to delete this?</h>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" 
        data-dismiss="modal"><a href="./index.php?list_users" class='text-light
        text-decoration-none'>No</a> </button>
        <button type="button" class="btn btn-primary">
           <a href='index.php?delete_users=<?php echo $user_id ?>' 
            type="button" class="text-dark text-decoration-none"> Yes</a></button>
      </div>
    </div>
  </div>
</div>


<!-- Bootstrap JS and dependencies -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>