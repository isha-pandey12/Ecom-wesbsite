<!-- Bootstrap CSS CDN -->
<link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome CDN -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

 
 <h3 class="text-center text-success">All Payments</h3>
 <table class="table table-hover table-striped table-bordered">
            <thead class="thead-dark">
        <tr class="text-center">

    <?php 
    
    $get_payments="SELECT * FROM `user_payments`";
    $result=mysqli_query($con,$get_payments);
    $row_count=mysqli_num_rows($result);

    if($row_count==0){
        echo "<h2 class='text-danger text-center mt-5'>No payments received Yet</h2>";
    }else{
      echo "<tr>
      <th>SNo.</th>
      <th>Invoice No.</th>
      <th>Amount</th>
      <th>Payment Mode</th>
      <th>Order Date</th>
      <th>Delete</th>
  </tr>
  </thead>
  <tbody class='bg-light'>";
        $number=0;
        while($row_data=mysqli_fetch_assoc($result)){
            $order_id=$row_data['order_id'];
            $payment_id =$row_data['payment_id'];
            $amount=$row_data['amount'];
            $invoice_number=$row_data['invoice_number'];
            $payment_mode=$row_data['payment_mode'];
            $date=$row_data['date'];
            $number++;
            echo "
        <tr>
            <td>$number</td>
            <td>$invoice_number</td>
            <td>$amount</td>
            <td>$payment_mode</td>
            <td>$date</td>
           <td><a href='index.php?delete_payments=$payment_id'
           type='button' class='text-dark' data-toggle='modal'data-target='#exampleModalCenter'>
            <i class='fa fa-trash' aria-hidden='true'></i></a></td> 
           
        </tr>";
        }
        
    }

    ?>

    </tbody>
</table>


<!-- Modal -->
<div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" 
aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">Delete Confirmation</h5>

      </div>
      <div class="modal-body">
        <h>Are you sure you want to delete this?</h>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" 
        data-dismiss="modal"><a href="./index.php?list_payments" class='text-light
        text-decoration-none'>No</a> </button>
        <button type="button" class="btn btn-primary">
           <a href='index.php?delete_payments=<?php echo $payment_id ?>' 
            type="button" class="text-dark text-decoration-none"> Yes</a></button>
      </div>
    </div>
  </div>
</div>


<!-- Bootstrap JS and dependencies -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>