<!-- Bootstrap CSS CDN -->
<link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome CDN -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

 
 <h3 class="text-center text-success">All Orders</h3>
 <table class="table table-hover table-striped table-bordered">
            <thead class="thead-dark">
        <tr class="text-center">

    <?php 
    
    $get_orders="SELECT * FROM `user_orders`";
    $result=mysqli_query($con,$get_orders);
    $row_count=mysqli_num_rows($result);



    if($row_count==0){
        echo "<h2 class='text-danger text-center mt-5'>No Orders Yet</h2>";
    }else{
      echo "<tr>
      <th>SNo.</th>
      <th>Due Amount</th>
      <th>Invoice No.</th>
      <th>Total Products</th>
      <th>Order Date</th>
      <th>Status</th>
      <th>Delete</th>
  </tr>
  </thead>
  <tbody class='bg-light'>";
        $number=0;
        while($row_data=mysqli_fetch_assoc($result)){
            $order_id=$row_data['order_id'];
            $user_id=$row_data['user_id'];
            $amount_due=$row_data['amount_due'];
            $invoice_number=$row_data['invoice_number'];
            $total_products=$row_data['total_products'];
            $order_date=$row_data['order_date'];
            $order_status=$row_data['order_status'];
            $number++;
            echo "
        <tr>
            <td>$number</td>
            <td>$amount_due</td>
            <td>$invoice_number</td>
            <td>$total_products</td>
            <td>$order_date</td>
            <td>$order_status</td>
           <td><a href='index.php?delete_orders=<?php echo $order_id ?>' 
            type='button' class='text-dark' data-toggle='modal' 
            data-target='#exampleModalCenter'><i class='fa fa-trash' aria-hidden='true'></i></a></td>
        </tr>";
        }
        
    }

    ?>

    </tbody>
</table>


<!-- Modal -->
<div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" 
aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">Delete Confirmation</h5>

      </div>
      <div class="modal-body">
        <h>Are you sure you want to delete this?</h>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" 
        data-dismiss="modal"><a href="./index.php?list_orders" class='text-light
        text-decoration-none'>No</a> </button>
        <button type="button" class="btn btn-primary">
           <a href='index.php?delete_orders=<?php echo $order_id ?>' 
            type="button" class="text-dark text-decoration-none"> Yes</a></button>
      </div>
    </div>
  </div>
</div>


<!-- Bootstrap JS and dependencies -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>