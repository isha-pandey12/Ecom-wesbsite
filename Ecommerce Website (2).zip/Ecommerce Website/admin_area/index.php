<!-- connect file -->
<?php 
include('../includes/connect.php');
include('../functions/common_function.php');
session_start();
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <!-- bootstrap CSS link -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" 
    integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
     <!-- font awesome link -->
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" 
    integrity="sha512-1ycn6IcaQQ40/MKBW2W4Rhis/DbILU74C1vSrLJxCq57o941Ym01SwNsOMqvEBFlcgUa6xLiPY/NS5R+E6ztJQ==" crossorigin="anonymous" 
    referrerpolicy="no-referrer" />
        <!-- css file -->
        <link rel="stylesheet" href= "../style.css">
        <!-- Bootstrap JS and dependencies -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
       <style>
        .admin{
            width:100%;
            height:100px;
            object-fit:contain;
            padding-right:10px;
            
            padding-right:100px;
            }
            .footer{
                position:absolute;
                bottom:-85px;
            }
            .product_img{
                width:100px;
                object-fit:contain;
            }
            body{
                overflow-x:hidden;
            }
       </style>
</head>
<body>
        <!-- navbar -->
        <div class="container-fluid p-0">
            <!-- first child -->
            <nav class="navbar navbar.expand.lg navbar-light bg-dark">
            <div class="container-fluid">
                <img src="../images/logo.jpg" alt="" class="logo">
                <nav class="navbar navbar.expand.lg">
                    <ul class="navbar-nav">
                        <li class="nav-item">
                        <?php 
            if(!isset($_SESSION['username'])){
                echo "<li class='nav-item'>
              <a class='nav-link text-light' href='#'>Welcome Guest</a>
          </li>";
              }else{
                echo "<li class='nav-item'>
              <a class='nav-link text-light' href='#'>Welcome ". $_SESSION['username'] ."</a>
          </li>";
              }
    ?>
                        </li>
                    </ul>

                </nav>
            </div>
            </nav>


            <!-- second child -->
            <div class="bg-light">
                <a href="admin_login.php"><h5 class="text-dark text-decoration-none px-2">Login</h5></a>
                <h3 class="text-center p-2">Manage Details</h3>
            </div>

<?php  
    if(!isset($_SESSION['username'])){
        echo " <li class='nav-item'>
          <a class='nav-link' href='../users_area/user_login.php'></a>
      </li>";
      }else{
        echo " <li class='nav-item'>
        <a class='nav-link' href='../users_area/logout.php'></a>
    </li>";
      }
?>

            <!-- third child -->
            <div class="row">
                <div class="col-md-12 bg-dark p-3 d-flex align-items-center">
                    <div class="p-3">
                        <a href="#"><img src="../images/admin.jpg" alt="" class="admin"></a>
                        <p class="text-light">
                            
                        </p>
                    </div>
                    <div class="button text-center text-center">
                      <br>  <button class="rounded-pill my-3 border-radius-12 px-3"><a href="insert_product.php" class="nav-link text-dark my-1">Insert Products </a></button>
                        <button class=" rounded-pill my-3  px-3"><a href="index.php?view_products" class="nav-link text-dark  my-1">View Products </a></button>
                        <button class="rounded-pill my-3  px-3"><a href="index.php?insert_category" class="nav-link text-dark my-1">Insert Categories </a></button>
                        <button class="rounded-pill my-3  px-3"><a href="index.php?view_categories" class="nav-link text-dark my-1">View Categories </a></button>
                        <button class="rounded-pill my-3  px-3"><a href="index.php?insert_brand" class="nav-link text-dark my-1">Insert Brands </a></button> <br>
                        <button class="rounded-pill my-3  px-3"><a href="index.php?view_brands" class="nav-link text-dark my-1">View Brands </a></button>
                        <button class="rounded-pill my-3  px-3"><a href="index.php?list_orders" class="nav-link text-dark my-1">All Orders </a></button> 
                        <button class="rounded-pill my-3  px-3"><a href="index.php?list_payments" class="nav-link text-dark my-1">All Payments </a></button>
                        <button class="rounded-pill my-3  px-3"><a href="index.php?list_users" class="nav-link text-dark my-1">List Users </a></button>
                        <button class="rounded-pill my-3  px-3"><a href="../users_area/logout.php" class="nav-link text-dark my-1">Logout </a></button>
                    </div>
                </div>
            </div>




            <!-- fourth child -->
            <div class="container my-3">
                <?php  
                if(isset($_GET['insert_category'])){
                    include('insert_categories.php');
                }
                if(isset($_GET['insert_brand'])){
                    include('insert_brands.php');
                }
                if(isset($_GET['view_products'])){
                    include('view_products.php');
                }
                if(isset($_GET['edit_products'])){
                    include('edit_products.php');
                }
                if(isset($_GET['delete_product'])){
                    include('delete_product.php');
                }
                if(isset($_GET['view_categories'])){
                    include('view_categories.php');
                }
                if(isset($_GET['view_brands'])){
                    include('view_brands.php');
                }
                if(isset($_GET['edit_category'])){
                    include('edit_category.php');
                }
                if(isset($_GET['edit_brands'])){
                    include('edit_brands.php');
                }
                if(isset($_GET['delete_category'])){
                    include('delete_category.php');
                }
                if(isset($_GET['delete_brands'])){
                    include('delete_brands.php');
                }
                if(isset($_GET['list_orders'])){
                    include('list_orders.php');
                }
                if(isset($_GET['delete_orders'])){
                    include('delete_orders.php');
                }
                if(isset($_GET['list_payments'])){
                    include('list_payments.php');
                }
                if(isset($_GET['delete_payments'])){
                    include('delete_payments.php');
                }
                if(isset($_GET['list_users'])){
                    include('list_users.php');
                }
                if(isset($_GET['delete_users'])){
                    include('delete_users.php');
                }
                
                
                ?>
            </div>


            <!-- last child -->
                        <!-- <div class="bg-dark text-light p-3 text-center footer">
                          <p>All rights reserved @Designed by-Aditya 2024</p>
                        </div> -->
                        <?php  include("../includes/footer.php")  ?>
        </div>


    <!-- bootstrap JS link -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" 
    integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</body>
</html>